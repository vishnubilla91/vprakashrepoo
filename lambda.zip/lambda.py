#!/usr/bin/env python3

from unittest import result
import boto3
import datetime
import dateutil.relativedelta
import os
import pandas as pd

#Get the time period for DAILY data
today = datetime.datetime.now() #For end date
startDate= datetime.date(today.year, today.month, 1) # Starting date of the month using current date --> Will be used as starting time period

current_month_start = startDate.strftime('%Y-%m-%d')
current_date = today.strftime('%Y-%m-%d')

#Get the time period for MONTHLY DATA  of last month
start_day_of_3_month_prev = today + dateutil.relativedelta.relativedelta(months=-3)
day_of_6_month_prev = today + dateutil.relativedelta.relativedelta(months=-6)
start_day_of_6_month_prev = day_of_6_month_prev.replace(day=1)


#Convert date to string type
start_day_of_3_month_prev = start_day_of_3_month_prev.strftime('%Y-%m-%d')
start_day_of_6_month_prev = start_day_of_6_month_prev.strftime('%Y-%m-%d')

#Create a dictionary to save the cost data
cost_dict={"Date":[], "Granularity":[], "Service":[], "Environment":[], "Application":[], "Amount":[], "Unit":[]} # For EC2 and RDS cost data
all_service_cost_dict = {"Date":[], "Granularity":[], "Service":[], "Application":[], "Amount":[], "Unit":[]} # For all service cost data

#----------------Function to add EC2 and RDS cost report to dictionary -> Giving the service name as parameter------------------ 
def addReport(granularity, start, end, applicationName, serviceName):
    client = boto3.client('ce', region_name='us-east-1')

    results = []

    token = None
    while True:
        if token:
            kwargs = {'NextPageToken': token}
        else:
            kwargs = {}
            data = client.get_cost_and_usage(
                TimePeriod={'Start': start, 'End': end}, 
                Granularity=granularity, 
                Filter={ 'And':[
                        {'Dimensions': {'Key':'SERVICE', 'Values': [serviceName]}}, 
                        {'Tags':{'Key': 'lll:business:application-name', 'Values': [applicationName],'MatchOptions':['EQUALS']}}
                    ]
                }, 
            Metrics=['UnblendedCost'], 
            GroupBy=[{'Type': 'TAG', 'Key': 'lll:deployment:environment'}], 
            **kwargs)
        results += data['ResultsByTime']
        token = data.get('NextPageToken')
        if not token:
            break

    for result_by_time in results:
        for group in result_by_time['Groups']:
            amount = group['Metrics']['UnblendedCost']['Amount']
            unit = group['Metrics']['UnblendedCost']['Unit']
            cost_dict["Date"].append(result_by_time['TimePeriod']['Start'])
            cost_dict["Granularity"].append(granularity)
            cost_dict["Service"].append(serviceName)
            # To seperate the linked account and lll:deployment:environment$npd 
            envName = '\t'.join(group['Keys']) 
            envName = envName.split('$')[-1]

            cost_dict["Environment"].append(envName)
            cost_dict["Application"].append(applicationName)
            cost_dict["Amount"].append(amount)
            cost_dict["Unit"].append(unit)
   
#-----------Function to add all service cost report to a dictionary---------------
def add_all_service_cost_report(granularity, start, end, applicationName):
    client = boto3.client('ce', region_name='us-east-1')

    results = []

    token = None
    while True:
        if token:
            kwargs = {'NextPageToken': token}
        else:
            kwargs = {}
            data = client.get_cost_and_usage(
                TimePeriod={'Start': start, 'End':  end}, 
                Granularity= granularity, 
                Filter = {'Tags':{'Key': 'lll:business:application-name', 'Values': [applicationName]}},
                Metrics=['UnblendedCost'], 
                GroupBy=[{'Type': 'DIMENSION', 'Key': 'SERVICE'}], 
            **kwargs)
        results += data['ResultsByTime']
        token = data.get('NextPageToken')
        if not token:
            break

    for result_by_time in results:
        for group in result_by_time['Groups']:
            amount = group['Metrics']['UnblendedCost']['Amount']
            unit = group['Metrics']['UnblendedCost']['Unit']
            serviceName = '\t'.join(group['Keys'])
            all_service_cost_dict["Date"].append(result_by_time['TimePeriod']['Start'])
            all_service_cost_dict["Granularity"].append(granularity)
            all_service_cost_dict["Service"].append(serviceName)
            all_service_cost_dict["Application"].append(applicationName)
            all_service_cost_dict["Amount"].append(amount)
            all_service_cost_dict["Unit"].append(unit)

def lambda_handler(even=None, context=None):
    
    #------------------CREATE REPORT-------------------------
    
     # Daily report of 3 months till present day for EC2 and RDS service
    addReport("DAILY", start_day_of_6_month_prev, current_date, "plim", "Amazon Elastic Compute Cloud - Compute")
    addReport("DAILY",start_day_of_6_month_prev, current_date, "plim","Amazon Relational Database Service")

    cost_df = pd.DataFrame.from_dict(cost_dict)                                     # convert the dictionary to dataframe
    cost_df.to_csv (r'/tmp/plim_nonprod_ec2_rds_cost.csv', index = False, header=True)            # Convert Dataframe to csv and store int tmp file given for lambda function


     # Daily report for last 3 months till present day for all service
    add_all_service_cost_report("DAILY", start_day_of_6_month_prev, current_date, "plim")

    all_service_cost_df = pd.DataFrame.from_dict(all_service_cost_dict)                #convert the dictionary to dataframe
    all_service_cost_df.to_csv(r'/tmp/plim_nonprod_all_service_cost.csv', index=False, header=True) # Convert Dataframe to csv and store int tmp file given for lambda function
    
    # ----------------UPLOAD TO S3 BUCKET------------------
    s3 = boto3.client('s3')
    #Upload EC2 and RDS cost report
    s3.upload_file("/tmp/plim_nonprod_ec2_rds_cost.csv", "cost-automation", "plim-nonprod-cost-report/plim_nonprod_ec2_rds_cost.csv") 
    
    #Upload all service cost report
    s3.upload_file("/tmp/plim_nonprod_all_service_cost.csv", "cost-automation", "plim-nonprod-cost-report/plim_nonprod_all_service_cost.csv")

if __name__ == '__main__':
    lambda_handler()
